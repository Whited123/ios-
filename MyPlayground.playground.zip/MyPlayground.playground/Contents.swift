import UIKit

class AbstractOperation {
    func logic(_ a:Double, _ b:Double) -> Double {
        return 0.0
    }
}

class plus: AbstractOperation {
    override func logic(_ a:Double, _ b:Double) -> Double {
        return a + b
    }
}

class bbelsem: AbstractOperation {
    override func logic(_ a:Double, _ b:Double) -> Double {
        return a - b
    }
}

class gopsem: AbstractOperation {
    override func logic(_ a:Double, _ b:Double) -> Double {
        return a * b
    }
}

class nanutsem: AbstractOperation {
    override func logic(_ a:Double, _ b:Double) -> Double {
        guard b != 0 else {
            fatalError("0으로 나눌 수 없습니다!!!")
        }
        return a / b
    }
}

class Calculator {
    var result:Double = 0
    func logic(_ operation: AbstractOperation, _ a:Double, _ b:Double) -> Double {
        let answer = operation.logic(a, b)
        result = answer
        return answer
    }
    func reset() {
        result = 0
    }
}
