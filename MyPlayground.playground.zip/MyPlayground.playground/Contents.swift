import UIKit

class Calculator {
    func plus(_ a:Double, _ b:Double) -> Double {
        return a + b
    }
    
    func bbelsem(_ a:Double, _ b:Double) -> Double {
        return a - b
    }
    
    func gopsem(_ a:Double, _ b:Double) -> Double {
        return a * b
    }
    
    func nanutsem(_ a:Double, _ b:Double) -> Double {
        guard b != 0 else {
            fatalError("0으로는 나눌 수 없습니다!!!")
        }
        return a / b
    }
}

let test = Calculator()
print(test.plus(1, 2))
print(test.bbelsem(4, 2))
print(test.gopsem(5, 2))
print(test.nanutsem(8, 2))
