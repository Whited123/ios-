import UIKit

class plus {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a + b
    }
}

class bbelsem {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a - b
    }
}

class gopsem {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a * b
    }
}

class nanutsem {
    func logic(_ a:Double, _ b:Double) -> Double {
        guard b != 0 else {
            fatalError("0은 나눌수 없습니다!!!")
        }
        return a / b
    }
}

class Calculator {
    var result:Double = 0
    
    func calculate(_ yeonsan: (Double, Double) -> Double, _ a: Double, _ b: Double) -> Double {
        let answer = yeonsan(a, b)
        result = answer
        return answer
    }

    func reset() {
        result = 0
    }
}

let test = Calculator()
let deohagi = plus()
let bbegi = bbelsem()
let gophagi = gopsem()
let nanugi = nanutsem()

print(test.calculate(plus.logic, 1, 2))
print(test.bbelsem(test.result, 1)) // 전의 연산 결과값에 그대로 계산
print(test.gopsem(test.result, 5))
test.reset() // AC 버튼, 연산값 0으로 초기화
print(test.plus(test.result, 4))
