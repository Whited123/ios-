import UIKit

class Calculator {
    var result:Double = 0
    func plus(_ a:Double, _ b:Double) -> Double {
        let result = a + b
        self.result = result
        return result
    }
    
    func bbelsem(_ a:Double, _ b:Double) -> Double {
        let result = a - b
        self.result = result
        return result
    }
    
    func gopsem(_ a:Double, _ b:Double) -> Double {
        let result = a * b
        self.result = result
        return result
    }
    
    func nanutsem(_ a:Double, _ b:Double) -> Double {
        guard b != 0 else {
            fatalError("0으로는 나눌 수 없습니다!!!")
        }
        let result = a / b
        self.result = result
        return result
    }
    func reset() {
        result = 0
    }
}

let test = Calculator()
print(test.plus(1, 2))
print(test.bbelsem(test.result, 1)) // 전의 연산 결과값에 그대로 계산
print(test.gopsem(test.result, 5))
test.reset() // AC 버튼, 연산값 0으로 초기화
print(test.plus(test.result, 4))
