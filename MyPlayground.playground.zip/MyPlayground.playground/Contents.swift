import UIKit

class plusOperation {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a + b
    }
}

class bbelsemOperation {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a - b
    }
}

class gopsemOperation {
    func logic(_ a:Double, _ b:Double) -> Double {
        return a * b
    }
}

class nanutsemOperation {
    func logic(_ a:Double, _ b:Double) -> Double {
        guard b != 0 else {
            fatalError("0은 나눌수 없습니다!!!")
        }
        return a / b
    }
}

class Calculator {
    var result:Double = 0
    
    func calculate(_ operation: (Double, Double) -> Double, _ a: Double, _ b: Double) -> Double {
        let answer = operation(a, b)
        result = answer
        return answer
    }

    func reset() {
        result = 0
    }
}

let test = Calculator()
let deohagi = plusOperation()
let bbegi = bbelsemOperation()
let gophagi = gopsemOperation()
let nanugi = nanutsemOperation()

print(test.calculate(deohagi.logic, 3, 2))
print(test.calculate(bbegi.logic, test.result, 3))
print(test.calculate(gophagi.logic, test.result, 8))
test.reset()
print(test.calculate(nanugi.logic, test.result, 2))
